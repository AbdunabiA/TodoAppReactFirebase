import { useState, useEffect } from 'react';
import {AiOutlinePlus} from 'react-icons/ai'
import Todo from './components/Todo';
import {db} from './firebase'
import {query, collection, onSnapshot, updateDoc, doc, addDoc, deleteDoc } from 'firebase/firestore'

function App() {

  const style = {
    bg: `h-screen w-screen p-4 bg-gradient-to-br from-[#0f0c29] to-[#302b63]`,
    container: `bg-blue-900/20 backdrop-blur max-w-[500px] w-full m-auto rounded-md shadow-lg shadow-black text-white p-4`,
    heading : `text-3xl font-bold text-center p-2`,
    form : `flex justify-between mt-4`,
    input : ` p-2 w-full text-xl rounded-md placeholder:text-white/70 focus:outline-none bg-blue-900`,
    button: `p-4 border-black border rounded-md bg-blue-900 ml-2 hover:bg-purple-900/80 hover:rotate-180 duration-300`,
    count : `text-center p-2`
  };

  const [todos, setTodos] = useState([])
  const [input, setInput] = useState('')

  //READING FROM FIREBASE
  useEffect(()=>{
    const q = query(collection(db, 'todo'))
    const unsubscribe = onSnapshot(q, querySnapshot => {
      let todosArr = []
      querySnapshot.forEach(doc => {
        todosArr.push({...doc.data(), id:doc.id})
      })
      setTodos(todosArr) 
    })
    return () => unsubscribe()
  }, [])


//TOGGLING COMPLETE
const toggleComplete = async (todo) => {
  await updateDoc(doc(db, 'todo', todo.id), {
    completed: !todo.completed
  })
}

//ADD NEW TODO TO FIREBASE
const createTodo = async (e) => {
  e.preventDefault()
  if(input.length < 3){
    alert('PLease enter a valid todo')
    return
  }
  await addDoc(collection(db, "todo"), {
    text: input,
    completed: false,
  });

  setInput('')
}


//DELETING TODO
const deleteTodo = async (id) => {
  await deleteDoc(doc(db, 'todo', id))
}

  return (
    <div className={style.bg}>
      <div className={style.container}>
        <h3 className={style.heading}>Todo app</h3>
        <form onSubmit={createTodo} className={style.form}>
          <input value={input} onChange={(e)=>setInput(e.target.value)} className={style.input} type="text" placeholder='Add todo'/>
          <button className={style.button}><AiOutlinePlus className='' size={30}/></button>
        </form>
        <ul>
          {todos.map((todo, index) => <Todo key={index} todo={todo} toggleComplete={toggleComplete} deleteTodo={deleteTodo}/>)}
        </ul>
        <p className={style.count}>{todos.length>1?`You have ${todos.length} todos`:todos.length === 1 ? `You have ${todos.length} todo` : "You don't have todos"}</p>
      </div>
    </div>
  );
}

export default App;
