import React from 'react'
import {FaRegTrashAlt} from 'react-icons/fa'

const Todo = ({todo, toggleComplete, deleteTodo}) => {

    const style = {
      li: `flex justify-between bg-blue-900 p-4 my-4 capitalize rounded-md`,
      liComplete: `flex justify-between bg-blue-900/50 p-4 my-4 capitalize rounded-md`,
      row: `flex`,
      text: `ml-3 cursor-pointer`,
      textComplete: `ml-3 cursor-pointer line-through`,
      button: `flex items-center`
    };

  return (
    <li className={todo.completed ? style.liComplete : style.li}>
      <div className={style.row}>
        <input
          onChange={() => toggleComplete(todo)}
          type="checkbox"
          checked={todo.completed ? "checked" : ""}
          className='cursor-pointer'
        />
        <p
          onClick={() => toggleComplete(todo)}
          className={todo.completed ? style.textComplete : style.text}
        >
          {todo.text}
        </p>
      </div>
      <button onClick={()=>deleteTodo(todo.id)}>
        <FaRegTrashAlt className='hover:text-green-600' size={20}/>
      </button>
    </li>
  );
}

export default Todo